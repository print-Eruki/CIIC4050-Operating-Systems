#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void Replace(char* src, char* dst, char find, char replacement);

void Insert(char* src, char* dst, char find, char* ins);

#endif