#ifndef FUNCTIONS_H
#define FUNCTIONS_H

const char* convert(int num);

char* numToStr(int num);

#endif