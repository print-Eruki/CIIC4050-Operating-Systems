#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int GenerateRandomNumber(int N);

int GetUserGuess();

int VerifyGuess(int, int);

#endif
