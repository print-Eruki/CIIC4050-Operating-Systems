#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void alignLeft(char** text);

void alignRight(char** text);

void justify(char** text);

void printText(char** text);

#endif